For the usage instructions see the guide: [naninovel.com/guide/spreadsheet](https://naninovel.com/guide/spreadsheet).

Be aware, that [Naninovel](https://u3d.as/1pg9) package is not distributed with the project, hence compilation errors will be produced after opening it for the first time; import Naninovel from the Asset Store to resolve the issues.

![](https://i.gyazo.com/e8b46fc74a5f633bdce9ec578b3ddf94.png)
